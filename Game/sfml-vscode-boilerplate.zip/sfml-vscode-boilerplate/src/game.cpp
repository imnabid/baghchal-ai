#include "includes/game.h"

Game::Game() :
	piece_selected(false),
	turn(0),
	GOATS(6),
	goat_eating_move(false),
	GOATS_KILLED(0)
{

	sf::FloatRect grid = board.grid_dimensions();
	width = 100;
	std::cout << grid.left << ',' << grid.top << ',' << grid.width << ',' << grid.height << '\n';
	lowx = grid.left;
	lowy = grid.top;
	highx = grid.left + grid.width;
	highy = grid.top + grid.height;

	tigers[0].set_position(lowx, lowy);
	tigers[1].set_position(highx, lowy);
	tigers[2].set_position(lowx, highy);
	tigers[3].set_position(highx, highy);
}

void Game::calc_possible_moves(sf::Vector2f point)
{
	int px = point.x, py = point.y, w = width, p = 1, q = 1;
	int bitx = ((px - lowx) / w) % 2 == 0 ? 0 : 1;
	int bity = ((py - lowy) / w) % 2 == 0 ? 0 : 1;

	// using XOR as same bit gives 0 and different bits gives 1
	if (bitx ^ bity)
	{
		int p = 1, q = 0;
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				int x1 = px + p * ((int)pow(-1, j) * w);
				int y1 = py + q * ((int)pow(-1, j) * w);
				if (x1 >= lowx and y1 >= lowy and x1 <= highx and y1 <= highy)
				{
					// fill the possible_moves vector
					possible_moves_utility(x1, y1);
				}
			}
			p = 0;
			q = 1;
		}
	}

	else
	{
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				int x1 = px + p * ((int)pow(-1, i) * w);
				int y1 = py - q * ((int)pow(-1, i) * w);
				if (x1 >= lowx and y1 >= lowy and x1 <= highx and y1 <= highy)
				{
					// fill the possible_moves vector
					possible_moves_utility(x1, y1);
				}
				if (p && q)
				{
					p = 0;
				}
				else
				{
					p = 1;
					q = q == 1 ? 0 : -1;
				}
			}
			p = 1;
			q = 1;
		}
	}
}

void Game::possible_moves_utility(int x, int y)
{
	if (turn and !tiger_there(x, y) and !goat_there(x, y))
	{
		possible_moves.push_back({ x, y });
	}
	if (turn == 0 and !goat_there(x, y) and !tiger_there(x, y))
	{
		possible_moves.push_back({ x, y });
	}
	if (turn and goat_there(x, y))
	{
		sf::Vector2f tiger_pos = tiger_pointer->get_position();
		eat_goat_check(tiger_pos.x, tiger_pos.y, x, y); //push the goat eating point to possible_moves
	}
}

void Game::select_tiger(int x, int y)
{
	for (int i = 0; i < 4; i++)
	{
		if (tigers[i].contains_point(x, y))
		{
			piece_selected = true;
			tiger_pointer = &tigers[i];
			tiger_pointer->set_color(154, 205, 50, 255);
			calc_possible_moves(tiger_pointer->get_position());
			create_circles();
			break;
		}
	}
}

void Game::select_goat(int x, int y)
{
	//goat placement for initial moves
	if (goats.size() < GOATS)
	{
		sf::Vector2i point = nearest_point(x, y);
		if (!tiger_there(point.x, point.y))
		{
			Goat* goat = new Goat;
			goat->set_position(point.x, point.y);
			goats.push_back(goat);
			turn = 1;
		}
	}

	//select goat
	else
	{
		for (Goat* goat : goats)
		{
			if (goat->contains_point(x, y))
			{
				piece_selected = true;
				goat_pointer = goat;
				goat->set_color(154, 205, 50, 255);
				calc_possible_moves(goat->get_position());
				create_circles();
				break;
			}
		}
	}
}

void Game::eat_goat_check(int x1, int y1, int x2, int y2)
{
	int w = width;
	int slope, px, py;

	slope = std::isinf((y2 - y1) / (float)(x2 - x1)) ? 2 : (y2 - y1) / (x2 - x1);
	if (slope == 0 and x2 > x1)
	{
		px = x2 + w;
		py = y2;
		goat_eat_check_utility(px, py, x2, y2);
	}
	else if (slope == 0 and x2 < x1)
	{
		px = x2 - w;
		py = y2;
		goat_eat_check_utility(px, py, x2, y2);
	}
	else if (slope == -1 and x2 > x1)
	{
		px = x2 + w;
		py = y2 - w;
		goat_eat_check_utility(px, py, x2, y2);
	}
	else if (slope == -1 and x1 > x2)
	{
		px = x2 - w;
		py = y2 + w;
		goat_eat_check_utility(px, py, x2, y2);
	}

	else if (slope == 1 and x2 > x1)
	{
		px = x2 + w;
		py = y2 + w;
		goat_eat_check_utility(px, py, x2, y2);
	}
	else if (slope == 1 and x1 > x2)
	{
		px = x2 - w;
		py = y2 - w;
		goat_eat_check_utility(px, py, x2, y2);
	}
	else if (slope == 2 and y2 > y1)
	{
		px = x2;
		py = y2 + w;
		goat_eat_check_utility(px, py, x2, y2);
	}
	else if (slope == 2 and y1 > y2)
	{
		px = x2;
		py = y2 - w;
		goat_eat_check_utility(px, py, x2, y2);
	}
}

void Game::goat_eat_check_utility(int x, int y, int x2, int y2)
{
	if (!goat_there(x, y) and !tiger_there(x, y))
	{
		change_goat_red(x2, y2); //change color of goat to red
		possible_moves.push_back({ x, y });
		sf::Vector2i next_pos(x, y);
		sf::Vector2i goat_pos(x2, y2);

		goat_eating_moves.push_back({ next_pos, goat_pos });
		goat_eating_move = true;
	}
}

void Game::create_circles()
{
	for (std::vector<int> x : possible_moves)
	{
		sf::CircleShape* circle = new sf::CircleShape(10);
		circle->setOrigin(10, 10);
		circle->setPosition(x[0], x[1]);
		circle->setOutlineThickness(2);
		circle->setOutlineColor(sf::Color(139, 59, 19));
		circles.push_back(*circle);
	}
}

void Game::move_piece(int x, int y)
{
	sf::Vector2i point = nearest_point(x, y);
	if (get_turn() == 1 and valid_click(point.x, point.y))
	{
		if (goat_eating_move)
		{
			for (auto data : goat_eating_moves)
			{
				sf::Vector2i next_pos = data[0];
				sf::Vector2i goat_pos = data[1];
				if (point == next_pos)
				{
					delete_goat(goat_pos);
				}
			}
		}
		tiger_pointer->set_position(point.x, point.y);
		tiger_pointer->reset_color();
		piece_selected = false;
		turn = 0;
		possible_moves.clear();
		circles.clear();
	}
	else if (get_turn() and !valid_click(point.x, point.y))
	{
		tiger_pointer->reset_color();
		piece_selected = false;
		possible_moves.clear();
		circles.clear();
	}
	else if (get_turn() == 0 and valid_click(point.x, point.y))
	{
		goat_pointer->set_position(point.x, point.y);
		goat_pointer->reset_color();
		piece_selected = false;
		turn = 1;
		possible_moves.clear();
		circles.clear();
	}
}

bool Game::valid_click(int x, int y)
{
	for (std::vector<int> point : possible_moves)
	{
		if (point[0] == x and point[1] == y)
		{
			return true;
		}
	}
	return false;
}

sf::Vector2i Game::nearest_point(int x, int y)
{
	sf::Vector2i point;
	int w1 = (int)(0.25 * width);
	int w2 = (int)(0.75 * width);
	int modx = (x - lowx) % width;
	int mody = (y - lowy) % width;
	if ((lowx - 15 <= x and x <= highx) && (lowy - 15 <= y and y <= highy))
	{
		if ((modx <= w1 or modx >= w2) and (mody <= w1 or mody >= w2))
		{
			int posx = round((float)(x - lowx) / width) * width + lowx;
			int posy = round((float)(y - lowy) / width) * width + lowy;
			point.x = posx;
			point.y = posy;
		}
	}
	return point;
}

bool Game::tiger_there(int x, int y)
{

	for (Tiger tiger : tigers)
	{
		if (&tiger != tiger_pointer and tiger.get_position() == sf::Vector2f(x, y))
		{
			return true;
		}
	}
	return false;
}

bool Game::goat_there(int x, int y)
{

	for (Goat* goat : goats)
	{
		if (goat->get_position() == sf::Vector2f(x, y))
		{
			return true;
		}
	}
	return false;
}

void Game::change_goat_red(int x, int y)
{
	for (Goat* goat : goats)
	{
		if (goat->get_position() == sf::Vector2f(x, y))
		{
			goat->set_color(255, 0, 0, 255);
		}
	}
}

void Game::delete_goat(sf::Vector2i goat_pos)
{
	std::vector<Goat*>::iterator it;
	for (it = goats.begin(); it != goats.end();)
	{
		if ((*it)->get_position() == (sf::Vector2f)(goat_pos))
		{
			std::cout << "deleting goat at " << (*it)->get_position().x << ',' << (*it)->get_position().y << '\n';
			delete *it;
			it = goats.erase(it);
			GOATS_KILLED += 1;
			goat_eating_move = false;
		}
		else
		{
			++it;
			(*it)->reset_color(); //to change goat from red to normal
		}
	}
}

int Game::get_turn()
{
	return turn;
}

bool Game::get_piece_selected()
{
	return piece_selected;
}